from app import app
from flask import request, redirect
from flask import render_template
from flask import jsonify, make_response

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/json", methods=["POST"])
def json_example():

    if request.is_json:

        req = request.get_json()

        response_body = {
            "ordre": req.get("ordre"),
            "cellule": req.get("cellule")
        }

        res = make_response(jsonify(response_body), 200)

        return res

    else:

        return make_response(jsonify({"message": "Request body must be JSON"}), 400)

@app.route("/chassis1")
def guestbook():
    return render_template("public/chassis1.html")

@app.route("/chassis1/create-entry", methods=["POST"])
def create_entry():

    req = request.get_json()

    print(req)

    res = make_response(jsonify({"message": "OK"}), 200)

    return res