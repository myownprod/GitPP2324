from app import app

@app.route("/admin")
def admin_dashboard():
    return "Admin dashboard"